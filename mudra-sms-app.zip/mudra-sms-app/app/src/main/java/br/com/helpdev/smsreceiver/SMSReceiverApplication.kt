package br.com.helpdev.smsreceiver

import android.app.Application
import android.content.IntentFilter
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.provider.Telephony
import br.com.helpdev.smsreceiver.receiver.SMSReceiver

class SMSReceiverApplication : Application() {
    // Called when the application is starting, before any other application objects have been created.
    // Overriding this method is totally optional!
    override fun onCreate() {
        super.onCreate()
        val smsReciever = SMSReceiver()
        val smsIntentFilter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        smsIntentFilter.addAction(Telephony.Sms.Intents.DATA_SMS_RECEIVED_ACTION)
        this.registerReceiver(smsReciever, smsIntentFilter)
        // Required initialization logic here!
    }

    // Called by the system when the device configuration changes while your component is running.
    // Overriding this method is totally optional!
    override fun onConfigurationChanged ( newConfig : Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    // This is called when the overall system is running low on memory,
    // and would like actively running processes to tighten their belts.
    // Overriding this method is totally optional!
    override fun onLowMemory() {
        super.onLowMemory()
    }
}