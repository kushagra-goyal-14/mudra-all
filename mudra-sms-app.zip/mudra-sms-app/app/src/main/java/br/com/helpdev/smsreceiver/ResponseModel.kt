package br.com.helpdev.smsreceiver

data class ResponseModel(
    val message: String
)