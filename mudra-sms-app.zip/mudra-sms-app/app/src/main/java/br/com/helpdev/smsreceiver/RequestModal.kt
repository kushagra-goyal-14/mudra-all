package br.com.helpdev.smsreceiver


data class RequestModel(
    val username: String,
    var password: String
)