package br.com.helpdev.smsreceiver

import android.Manifest
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Telephony
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import br.com.helpdev.smsreceiver.receiver.SMSReceiver
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {
    companion object {
        private const val REQUEST_CODE_SMS_PERMISSION = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestSmsPermission()

    }

    private fun requestSmsPermission() {
        val permission = Manifest.permission.RECEIVE_SMS
        val grant = ContextCompat.checkSelfPermission(this, permission)
        if (grant != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(permission),
                REQUEST_CODE_SMS_PERMISSION
            )
        }
        val response = ServiceBuilder.buildService(ApiInterface::class.java)
        var requestModel = RequestModel("hei", "yo")
        response.sendReq(requestModel).enqueue(
            object : Callback<ResponseModel> {
                override fun onResponse(
                    call: Call<ResponseModel>,
                    response: Response<ResponseModel>
                ) {
                    Toast.makeText(this@MainActivity,response.message().toString(),Toast.LENGTH_LONG).show()
                }

                override fun onFailure(call: Call<ResponseModel>, t: Throwable) {
                    Toast.makeText(this@MainActivity,t.toString(),Toast.LENGTH_LONG).show()
                }

            }
        )
//        }else{
//            val smsReciever = SMSReceiver()
//            val smsIntentFilter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
//            smsIntentFilter.addAction(Telephony.Sms.Intents.DATA_SMS_RECEIVED_ACTION)
//            this.registerReceiver(smsReciever, smsIntentFilter)
//        }
    }

}
